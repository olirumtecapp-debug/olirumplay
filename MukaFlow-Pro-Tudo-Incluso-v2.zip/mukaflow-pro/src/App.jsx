import React, { useState, useEffect, useRef } from 'react';
import {
  Play, Pause, SkipBack, SkipForward, Volume2, VolumeX,
  Repeat, Shuffle, Heart, Download, Trash2, Search,
  Music, WifiOff, PlusCircle, Compass, HardDrive,
  CheckCircle2, Loader2, Share2, Disc, Sparkles, Sliders,
  FolderOpen, FileAudio, Clock, ListMusic, ChevronDown,
  Copy, Check, Terminal, Layers, RefreshCw, AlertCircle,
  Smartphone, Archive, Upload, Radio, Flame, X, MoreVertical,
  Gauge, Moon, Plus, FolderPlus, ArrowUpDown, ExternalLink
} from 'lucide-react';

// ============================================================================
// 1. CATÁLOGO INICIAL DE DEMONSTRAÇÃO (STREAMS MP3 COMPLETOS E VERIFICADOS)
// ============================================================================
const DEMO_CATALOG = [
  {
    id: 'muka-demo-1',
    title: 'Midnight Cyber Drive',
    artist: 'Muka Synth Collective',
    album: 'Neon Horizons Vol. 1',
    duration: 372,
    cover: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    genre: 'Synthwave',
    source: 'cloud',
    bitrate: '320 kbps'
  },
  {
    id: 'muka-demo-2',
    title: 'São Paulo Lo-Fi Rain',
    artist: 'BeatMaker BR',
    album: 'Madrugada Chill',
    duration: 425,
    cover: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
    genre: 'Lo-Fi Beats',
    source: 'cloud',
    bitrate: '320 kbps'
  },
  {
    id: 'muka-demo-3',
    title: 'Subgrave Trap Baile',
    artist: 'DJ Kora & MC Zeca',
    album: 'Fluxo 2026',
    duration: 344,
    cover: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=600&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
    genre: 'Trap / Funk',
    source: 'cloud',
    bitrate: '256 kbps'
  },
  {
    id: 'muka-demo-4',
    title: 'Aurora Deep Progressive',
    artist: 'Alok & Vintage Style',
    album: 'Festival Mainstage',
    duration: 302,
    cover: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3',
    genre: 'Electronic',
    source: 'cloud',
    bitrate: '320 kbps'
  },
  {
    id: 'muka-demo-5',
    title: 'Acoustic Horizon Session',
    artist: 'Luna & The Waves',
    album: 'Unplugged Studio',
    duration: 355,
    cover: 'https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=600&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3',
    genre: 'Acoustic',
    source: 'cloud',
    bitrate: '320 kbps'
  }
];

const EQ_PRESETS = {
  flat: { name: 'Flat (Original)', gains: [0, 0, 0, 0, 0] },
  bass: { name: 'Bass Boost (Grave Forte)', gains: [8, 6, 0, -1, 1] },
  electronic: { name: 'Electronic / EDM', gains: [6, 3, -2, 3, 6] },
  vocal: { name: 'Vocal & Podcast', gains: [-3, -1, 5, 4, 1] },
  rock: { name: 'Rock / Guitarra', gains: [5, 2, -2, 4, 5] },
  lofi: { name: 'Lo-Fi Warm Night', gains: [5, 4, 1, -4, -6] }
};

const EQ_BANDS = [
  { freq: 60, label: '60Hz', desc: 'Sub-Grave' },
  { freq: 230, label: '230Hz', desc: 'Grave' },
  { freq: 910, label: '910Hz', desc: 'Médio' },
  { freq: 3600, label: '3.6kHz', desc: 'Presença' },
  { freq: 14000, label: '14kHz', desc: 'Agudo' }
];

// ============================================================================
// 2. MOTOR INDEXED-DB PARA ARMAZENAMENTO OFFLINE E ARQUIVOS LOCAIS PERSISTENTES
// ============================================================================
const DB_NAME = 'MukaFlowProDB';
const DB_VERSION = 2;
const STORE_TRACKS = 'tracks';
const STORE_PLAYLISTS = 'playlists';

const openDatabase = () => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains(STORE_TRACKS)) {
        db.createObjectStore(STORE_TRACKS, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_PLAYLISTS)) {
        db.createObjectStore(STORE_PLAYLISTS, { keyPath: 'id' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
};

const saveTrackToIDB = async (track, blob) => {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_TRACKS, 'readwrite');
    const store = tx.objectStore(STORE_TRACKS);
    const record = {
      ...track,
      audioBlob: blob,
      savedAt: new Date().toISOString(),
      fileSize: blob ? blob.size : (track.fileSize || 0)
    };
    store.put(record);
    tx.oncomplete = () => resolve(record);
    tx.onerror = () => reject(tx.error);
  });
};

const getAllTracksFromIDB = async () => {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_TRACKS, 'readonly');
    const store = tx.objectStore(STORE_TRACKS);
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
};

const deleteTrackFromIDB = async (id) => {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_TRACKS, 'readwrite');
    const store = tx.objectStore(STORE_TRACKS);
    store.delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
};

// ============================================================================
// 3. PARSER BINÁRIO NATIVO DE TAGS ID3v2 (EXTRAI TÍTULO, ARTISTA, ÁLBUM E CAPA)
// ============================================================================
const generateGradientCover = (title = 'Muka') => {
  const palettes = [
    ['#7c3aed', '#ec4899'],
    ['#2563eb', '#06b6d4'],
    ['#059669', '#10b981'],
    ['#ea580c', '#f59e0b'],
    ['#9333ea', '#3b82f6']
  ];
  const idx = Math.abs(title.split('').reduce((acc, c) => acc + c.charCodeAt(0), 0)) % palettes.length;
  const [c1, c2] = palettes[idx];
  const initials = title.replace(/[^a-zA-Z0-9 ]/g, '').trim().slice(0, 2).toUpperCase() || 'MK';
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400" viewBox="0 0 400 400">
    <defs>
      <linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="${c1}"/>
        <stop offset="100%" stop-color="${c2}"/>
      </linearGradient>
    </defs>
    <rect width="400" height="400" fill="url(#g)"/>
    <circle cx="200" cy="200" r="110" fill="rgba(0,0,0,0.28)"/>
    <circle cx="200" cy="200" r="32" fill="rgba(255,255,255,0.18)"/>
    <text x="50%" y="54%" dominant-baseline="middle" text-anchor="middle" fill="#ffffff" font-family="sans-serif" font-weight="800" font-size="64">${initials}</text>
  </svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
};

const parseID3v2Metadata = async (file) => {
  const cleanName = file.name.replace(/\.[^/.]+$/, '');
  const parts = cleanName.split(' - ');
  const fallbackMeta = {
    title: parts.length > 1 ? parts.slice(1).join(' - ').trim() : cleanName,
    artist: parts.length > 1 ? parts[0].trim() : 'Arquivo Local',
    album: 'Armazenamento Local',
    cover: generateGradientCover(cleanName)
  };

  try {
    const slice = file.slice(0, 262144);
    const buffer = await slice.arrayBuffer();
    const view = new DataView(buffer);

    if (
      view.byteLength < 10 ||
      view.getUint8(0) !== 0x49 || // 'I'
      view.getUint8(1) !== 0x44 || // 'D'
      view.getUint8(2) !== 0x33    // '3'
    ) {
      return fallbackMeta;
    }

    const version = view.getUint8(3);
    const tagSize =
      ((view.getUint8(6) & 0x7f) << 21) |
      ((view.getUint8(7) & 0x7f) << 14) |
      ((view.getUint8(8) & 0x7f) << 7) |
      (view.getUint8(9) & 0x7f);

    let offset = 10;
    const limit = Math.min(tagSize + 10, view.byteLength);

    const decodeText = (bytes) => {
      if (!bytes || bytes.length === 0) return '';
      const encoding = bytes[0];
      const content = bytes.subarray(1);
      try {
        if (encoding === 0) return new TextDecoder('iso-8859-1').decode(content).replace(/\0/g, '').trim();
        if (encoding === 1) return new TextDecoder('utf-16').decode(content).replace(/\0/g, '').trim();
        if (encoding === 2) return new TextDecoder('utf-16be').decode(content).replace(/\0/g, '').trim();
        return new TextDecoder('utf-8').decode(content).replace(/\0/g, '').trim();
      } catch {
        return '';
      }
    };

    while (offset + 10 < limit) {
      const f0 = view.getUint8(offset);
      if (f0 === 0) break;

      const frameId = String.fromCharCode(
        f0,
        view.getUint8(offset + 1),
        view.getUint8(offset + 2),
        view.getUint8(offset + 3)
      );

      let frameSize = 0;
      if (version === 4) {
        frameSize =
          ((view.getUint8(offset + 4) & 0x7f) << 21) |
          ((view.getUint8(offset + 5) & 0x7f) << 14) |
          ((view.getUint8(offset + 6) & 0x7f) << 7) |
          (view.getUint8(offset + 7) & 0x7f);
      } else {
        frameSize = view.getUint32(offset + 4);
      }

      if (frameSize <= 0 || offset + 10 + frameSize > limit) break;
      const frameBytes = new Uint8Array(buffer, offset + 10, frameSize);

      if (frameId === 'TIT2') {
        const val = decodeText(frameBytes);
        if (val) fallbackMeta.title = val;
      } else if (frameId === 'TPE1') {
        const val = decodeText(frameBytes);
        if (val) fallbackMeta.artist = val;
      } else if (frameId === 'TALB') {
        const val = decodeText(frameBytes);
        if (val) fallbackMeta.album = val;
      } else if (frameId === 'APIC') {
        let p = 1;
        let mime = '';
        while (p < frameBytes.length && frameBytes[p] !== 0) {
          mime += String.fromCharCode(frameBytes[p]);
          p++;
        }
        p++; // pula byte nulo do mime
        p++; // pula byte de picture type
        while (p < frameBytes.length && frameBytes[p] !== 0) p++;
        p++;
        if (frameBytes[p] === 0) p++;
        if (p < frameBytes.length) {
          const imgBlob = new Blob([frameBytes.subarray(p)], { type: mime || 'image/jpeg' });
          fallbackMeta.cover = URL.createObjectURL(imgBlob);
        }
      }

      offset += 10 + frameSize;
    }
  } catch (err) {
    console.warn('Fallback ID3 parser:', err);
  }

  return fallbackMeta;
};

const getAudioFileDuration = (url) => {
  return new Promise((resolve) => {
    const tempAudio = new Audio();
    tempAudio.preload = 'metadata';
    const timer = setTimeout(() => resolve(210), 3500);
    tempAudio.onloadedmetadata = () => {
      clearTimeout(timer);
      resolve(tempAudio.duration && isFinite(tempAudio.duration) ? Math.round(tempAudio.duration) : 210);
    };
    tempAudio.onerror = () => {
      clearTimeout(timer);
      resolve(210);
    };
    tempAudio.src = url;
  });
};

// ============================================================================
// 4. COMPONENTE PRINCIPAL DO MUKAFLOW PRO
// ============================================================================
export default function App() {
  // Navegação principal
  const [activeTab, setActiveTab] = useState('explore'); // explore | local | offline | extractor | handoff
  const [localFilter, setLocalFilter] = useState('all'); // all | artists | albums | playlists

  // Catálogos e Listas
  const [cloudTracks, setCloudTracks] = useState(DEMO_CATALOG);
  const [localTracks, setLocalTracks] = useState([]);
  const [offlineTracks, setOfflineTracks] = useState([]);
  const [favorites, setFavorites] = useState(() => {
    try { return JSON.parse(localStorage.getItem('muka_pro_favs') || '[]'); } catch { return []; }
  });
  const [playlists, setPlaylists] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('muka_pro_playlists') || JSON.stringify([
        { id: 'pl-treino', name: 'Treino Pesado 🔥', trackIds: ['muka-demo-1', 'muka-demo-3'] },
        { id: 'pl-foco', name: 'Coding & Foco 💻', trackIds: ['muka-demo-2', 'muka-demo-5'] }
      ]));
    } catch { return []; }
  });

  // Estado do Player e Fila
  const [queue, setQueue] = useState(DEMO_CATALOG);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.9);
  const [isMuted, setIsMuted] = useState(false);
  const [isShuffle, setIsShuffle] = useState(false);
  const [repeatMode, setRepeatMode] = useState('off'); // off | all | one
  const [playbackRate, setPlaybackRate] = useState(1.0);

  // Modais e Gavetas do Player
  const [showFullPlayer, setShowFullPlayer] = useState(false);
  const [playerSubView, setPlayerSubView] = useState('cover'); // cover | eq | queue | lyrics
  const [eqPreset, setEqPreset] = useState('flat');
  const [eqGains, setEqGains] = useState([0, 0, 0, 0, 0]);
  const [sleepTimerMinutes, setSleepTimerMinutes] = useState(0);
  const [sleepRemainingSec, setSleepRemainingSec] = useState(0);

  // Busca Online (iTunes API)
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchingOnline, setIsSearchingOnline] = useState(false);

  // Importação Local e Downloads
  const [downloadingIds, setDownloadingIds] = useState({});
  const [isScanningLocal, setIsScanningLocal] = useState(false);
  const [scanProgress, setScanProgress] = useState({ done: 0, total: 0 });
  const [persistLocalToIDB, setPersistLocalToIDB] = useState(true);
  const [localSearch, setLocalSearch] = useState('');
  const [isDraggingOver, setIsDraggingOver] = useState(false);

  // Extrator & Nova Playlist
  const [extractorInput, setExtractorInput] = useState('');
  const [extractorTitle, setExtractorTitle] = useState('');
  const [extractorArtist, setExtractorArtist] = useState('');
  const [backendApiUrl, setBackendApiUrl] = useState(() => localStorage.getItem('muka_pro_api') || '');
  const [isExtracting, setIsExtracting] = useState(false);
  const [newPlaylistName, setNewPlaylistName] = useState('');
  const [playlistModalTrack, setPlaylistModalTrack] = useState(null);

  // Notificações e Handoff
  const [toast, setToast] = useState(null);
  const [copiedKey, setCopiedKey] = useState('');

  // Referências de Áudio, Web Audio API e Canvas
  const audioRef = useRef(null);
  const audioCtxRef = useRef(null);
  const analyserRef = useRef(null);
  const eqFiltersRef = useRef([]);
  const sourceNodeRef = useRef(null);
  const canvasRef = useRef(null);
  const animFrameRef = useRef(null);
  const fileInputRef = useRef(null);
  const folderInputRef = useRef(null);

  const currentTrack = queue[currentIndex] || DEMO_CATALOG[0];

  const notify = (msg, type = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3400);
  };

  // ============================================================================
  // 5. CARREGAMENTO DO BANCO INDEXEDDB NA INICIALIZAÇÃO
  // ============================================================================
  useEffect(() => {
    loadSavedDatabase();
    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, []);

  const loadSavedDatabase = async () => {
    try {
      const saved = await getAllTracksFromIDB();
      const hydrated = saved.map((item) => ({
        ...item,
        audioUrl: item.audioBlob ? URL.createObjectURL(item.audioBlob) : item.audioUrl,
        isSavedOffline: true
      }));
      setOfflineTracks(hydrated.filter((t) => t.source !== 'local-device'));
      const savedLocals = hydrated.filter((t) => t.source === 'local-device');
      if (savedLocals.length > 0) {
        setLocalTracks(savedLocals);
      }
    } catch (err) {
      console.error('Erro ao carregar IndexedDB:', err);
    }
  };

  useEffect(() => {
    localStorage.setItem('muka_pro_favs', JSON.stringify(favorites));
  }, [favorites]);

  useEffect(() => {
    localStorage.setItem('muka_pro_playlists', JSON.stringify(playlists));
  }, [playlists]);

  // ============================================================================
  // 6. SLEEP TIMER (DESLIGAMENTO AUTOMÁTICO)
  // ============================================================================
  useEffect(() => {
    if (sleepRemainingSec <= 0) return;
    const timer = setInterval(() => {
      setSleepRemainingSec((prev) => {
        if (prev <= 1) {
          if (audioRef.current) audioRef.current.pause();
          setIsPlaying(false);
          setSleepTimerMinutes(0);
          notify('Sleep Timer finalizado: reprodução pausada 🌙', 'info');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [sleepRemainingSec]);

  const activateSleepTimer = (mins) => {
    setSleepTimerMinutes(mins);
    setSleepRemainingSec(mins * 60);
    if (mins > 0) notify(`Sleep Timer ativado para ${mins} minutos 🌙`);
    else notify('Sleep Timer desativado');
  };

  // ============================================================================
  // 7. WEB AUDIO API (EQUALIZADOR DE 5 BANDAS + ANALISADOR DE ESPECTRO)
  // ============================================================================
  const setupWebAudioGraph = () => {
    if (!audioRef.current || audioCtxRef.current) return;
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      const ctx = new AudioCtx();
      const source = ctx.createMediaElementSource(audioRef.current);

      const filters = EQ_BANDS.map((band, idx) => {
        const filter = ctx.createBiquadFilter();
        filter.type = idx === 0 ? 'lowshelf' : idx === EQ_BANDS.length - 1 ? 'highshelf' : 'peaking';
        filter.frequency.value = band.freq;
        filter.Q.value = 1.1;
        filter.gain.value = eqGains[idx] || 0;
        return filter;
      });

      const analyser = ctx.createAnalyser();
      analyser.fftSize = 64;

      // Encadeia: source -> f0 -> f1 -> f2 -> f3 -> f4 -> analyser -> destination
      source.connect(filters[0]);
      for (let i = 0; i < filters.length - 1; i++) {
        filters[i].connect(filters[i + 1]);
      }
      filters[filters.length - 1].connect(analyser);
      analyser.connect(ctx.destination);

      audioCtxRef.current = ctx;
      sourceNodeRef.current = source;
      eqFiltersRef.current = filters;
      analyserRef.current = analyser;
      renderVisualizerLoop();
    } catch (e) {
      console.warn('Web Audio API fallback (CORS stream):', e);
    }
  };

  const updateEqBandGain = (index, dbValue) => {
    const clamped = Math.max(-12, Math.min(12, Number(dbValue)));
    const nextGains = [...eqGains];
    nextGains[index] = clamped;
    setEqGains(nextGains);
    setEqPreset('custom');
    if (eqFiltersRef.current[index] && audioCtxRef.current) {
      eqFiltersRef.current[index].gain.setTargetAtTime(clamped, audioCtxRef.current.currentTime, 0.015);
    }
  };

  const applyEqPreset = (presetKey) => {
    const preset = EQ_PRESETS[presetKey];
    if (!preset) return;
    setEqPreset(presetKey);
    setEqGains([...preset.gains]);
    preset.gains.forEach((g, idx) => {
      if (eqFiltersRef.current[idx] && audioCtxRef.current) {
        eqFiltersRef.current[idx].gain.setTargetAtTime(g, audioCtxRef.current.currentTime, 0.02);
      }
    });
    notify(`Equalizador: ${preset.name} 🎚️`);
  };

  const renderVisualizerLoop = () => {
    if (!canvasRef.current || !analyserRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const analyser = analyserRef.current;
    const bufferLength = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);

    const draw = () => {
      animFrameRef.current = requestAnimationFrame(draw);
      analyser.getByteFrequencyData(dataArray);
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const barWidth = (canvas.width / bufferLength) * 1.6;
      let x = 0;

      for (let i = 0; i < bufferLength; i++) {
        const barHeight = (dataArray[i] / 255) * canvas.height;
        const grad = ctx.createLinearGradient(0, canvas.height, 0, 0);
        grad.addColorStop(0, '#7c3aed');
        grad.addColorStop(0.6, '#d946ef');
        grad.addColorStop(1, '#38bdf8');
        ctx.fillStyle = grad;
        ctx.fillRect(x, canvas.height - barHeight, barWidth - 2, barHeight);
        x += barWidth;
      }
    };
    draw();
  };

  // ============================================================================
  // 8. CONTROLES DE REPRODUÇÃO E MEDIA SESSION API (TELA DE BLOQUEIO ANDROID)
  // ============================================================================
  useEffect(() => {
    if (!audioRef.current || !currentTrack) return;
    const offlineVersion = offlineTracks.find((t) => t.id === currentTrack.id);
    const localVersion = localTracks.find((t) => t.id === currentTrack.id);
    const playSourceUrl = offlineVersion
      ? offlineVersion.audioUrl
      : localVersion
      ? localVersion.audioUrl
      : currentTrack.audioUrl;

    if (audioRef.current.src !== playSourceUrl) {
      audioRef.current.src = playSourceUrl;
      audioRef.current.load();
      audioRef.current.playbackRate = playbackRate;
    }

    if (isPlaying) {
      audioRef.current.play().catch(() => setIsPlaying(false));
    }

    if ('mediaSession' in navigator) {
      navigator.mediaSession.metadata = new window.MediaMetadata({
        title: currentTrack.title,
        artist: currentTrack.artist,
        album: currentTrack.album || 'MukaFlow Pro',
        artwork: [{ src: currentTrack.cover, sizes: '512x512', type: 'image/jpeg' }]
      });
      navigator.mediaSession.setActionHandler('play', () => togglePlay());
      navigator.mediaSession.setActionHandler('pause', () => togglePlay());
      navigator.mediaSession.setActionHandler('previoustrack', () => handlePrev());
      navigator.mediaSession.setActionHandler('nexttrack', () => handleNext());
    }
  }, [currentIndex, queue]);

  const togglePlay = () => {
    if (!audioRef.current) return;
    setupWebAudioGraph();
    if (audioCtxRef.current && audioCtxRef.current.state === 'suspended') {
      audioCtxRef.current.resume();
    }
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play().then(() => setIsPlaying(true)).catch((e) => {
        console.error(e);
        notify('Não foi possível reproduzir esta faixa.', 'error');
      });
    }
  };

  const selectAndPlayTrack = (track, customQueue = null) => {
    setupWebAudioGraph();
    if (customQueue && customQueue.length > 0) {
      setQueue(customQueue);
      const idx = customQueue.findIndex((t) => t.id === track.id);
      setCurrentIndex(idx >= 0 ? idx : 0);
    } else {
      const idx = queue.findIndex((t) => t.id === track.id);
      if (idx >= 0) {
        setCurrentIndex(idx);
      } else {
        setQueue((prev) => [track, ...prev]);
        setCurrentIndex(0);
      }
    }
    setIsPlaying(true);
  };

  const handleNext = () => {
    if (queue.length === 0) return;
    if (repeatMode === 'one') {
      audioRef.current.currentTime = 0;
      audioRef.current.play();
      return;
    }
    if (isShuffle && queue.length > 1) {
      let rnd = Math.floor(Math.random() * queue.length);
      if (rnd === currentIndex) rnd = (rnd + 1) % queue.length;
      setCurrentIndex(rnd);
    } else {
      setCurrentIndex((prev) => (prev + 1) % queue.length);
    }
    setIsPlaying(true);
  };

  const handlePrev = () => {
    if (queue.length === 0) return;
    if (audioRef.current && audioRef.current.currentTime > 3) {
      audioRef.current.currentTime = 0;
      return;
    }
    setCurrentIndex((prev) => (prev - 1 + queue.length) % queue.length);
    setIsPlaying(true);
  };

  const handleSeek = (e) => {
    const val = parseFloat(e.target.value);
    setCurrentTime(val);
    if (audioRef.current) audioRef.current.currentTime = val;
  };

  const changeSpeed = (rate) => {
    setPlaybackRate(rate);
    if (audioRef.current) audioRef.current.playbackRate = rate;
    notify(`Velocidade ajustada para ${rate}x ⚡`);
  };

  // ============================================================================
  // 9. SCANNER E IMPORTADOR DE MÚSICAS DO ARMAZENAMENTO LOCAL (ID3v2 + PASTAS)
  // ============================================================================
  const processLocalAudioFiles = async (fileList) => {
    if (!fileList || fileList.length === 0) return;
    const validExtensions = /\.(mp3|m4a|wav|flac|ogg|aac|opus|webm)$/i;
    const audioFiles = Array.from(fileList).filter(
      (file) => file.type.startsWith('audio/') || validExtensions.test(file.name)
    );

    if (audioFiles.length === 0) {
      notify('Nenhum arquivo de áudio compatível (.mp3, .m4a, .wav, .flac) encontrado.', 'error');
      return;
    }

    setIsScanningLocal(true);
    setScanProgress({ done: 0, total: audioFiles.length });

    const importedBatch = [];

    for (let i = 0; i < audioFiles.length; i++) {
      const file = audioFiles[i];
      const objectUrl = URL.createObjectURL(file);
      const id3 = await parseID3v2Metadata(file);
      const dur = await getAudioFileDuration(objectUrl);

      const relativeFolder = file.webkitRelativePath
        ? file.webkitRelativePath.split('/')[0]
        : 'Memória Interna';

      const newLocalTrack = {
        id: `local-${file.name}-${file.size}-${file.lastModified}`,
        title: id3.title,
        artist: id3.artist,
        album: id3.album !== 'Armazenamento Local' ? id3.album : relativeFolder,
        duration: dur,
        cover: id3.cover,
        audioUrl: objectUrl,
        genre: file.name.split('.').pop().toUpperCase(),
        source: 'local-device',
        fileSize: file.size,
        fileName: file.name,
        folderName: relativeFolder,
        isSavedOffline: persistLocalToIDB
      };

      if (persistLocalToIDB) {
        try {
          await saveTrackToIDB(newLocalTrack, file);
        } catch (e) {
          console.warn('Espaço IndexedDB cheio para este arquivo:', e);
        }
      }

      importedBatch.push(newLocalTrack);
      setScanProgress({ done: i + 1, total: audioFiles.length });
    }

    setLocalTracks((prev) => {
      const existingIds = new Set(prev.map((t) => t.id));
      const uniqueNew = importedBatch.filter((t) => !existingIds.has(t.id));
      return [...uniqueNew, ...prev];
    });

    setIsScanningLocal(false);
    notify(`${importedBatch.length} música(s) local(is) carregada(s) com leitor ID3! 🎵`);

    if (importedBatch.length > 0) {
      selectAndPlayTrack(importedBatch[0], [...importedBatch, ...localTracks]);
    }
  };

  const handleDropFiles = async (e) => {
    e.preventDefault();
    setIsDraggingOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      await processLocalAudioFiles(e.dataTransfer.files);
    }
  };

  const removeLocalTrack = async (id) => {
    await deleteTrackFromIDB(id);
    setLocalTracks((prev) => prev.filter((t) => t.id !== id));
    notify('Música removida da biblioteca local.', 'info');
  };

  // ============================================================================
  // 10. DOWNLOAD OFFLINE (CLOUD -> INDEXEDDB + EXPORTAR .MP3)
  // ============================================================================
  const handleDownloadOffline = async (track) => {
    if (offlineTracks.some((t) => t.id === track.id)) {
      notify('Esta faixa já está salva no seu Cofre Offline!', 'info');
      return;
    }

    setDownloadingIds((prev) => ({ ...prev, [track.id]: true }));
    try {
      const resp = await fetch(track.audioUrl);
      if (!resp.ok) throw new Error('Falha de rede');
      const blob = await resp.blob();
      await saveTrackToIDB({ ...track, source: 'cloud-offline' }, blob);
      await loadSavedDatabase();
      notify(`"${track.title}" baixada para ouvir sem internet! 📥`);
    } catch (err) {
      console.error(err);
      notify('Não foi possível baixar diretamente devido a bloqueio CORS da origem.', 'error');
    } finally {
      setDownloadingIds((prev) => ({ ...prev, [track.id]: false }));
    }
  };

  const exportMp3ToDevice = (track) => {
    const a = document.createElement('a');
    a.href = track.audioUrl;
    a.download = `${track.artist} - ${track.title}.mp3`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    notify('Transferindo arquivo .MP3 para a pasta Downloads do aparelho!');
  };

  const removeOfflineTrack = async (id) => {
    await deleteTrackFromIDB(id);
    await loadSavedDatabase();
    notify('Faixa removida do armazenamento offline.', 'info');
  };

  // ============================================================================
  // 11. BUSCA ONLINE EM TEMPO REAL (API PÚBLICA DO ITUNES)
  // ============================================================================
  const searchOnlineMusic = async (e) => {
    if (e) e.preventDefault();
    if (!searchQuery.trim()) {
      setCloudTracks(DEMO_CATALOG);
      return;
    }
    setIsSearchingOnline(true);
    try {
      const res = await fetch(
        `https://itunes.apple.com/search?term=${encodeURIComponent(searchQuery)}&entity=song&limit=18`
      );
      const data = await res.json();
      if (data.results && data.results.length > 0) {
        const mapped = data.results
          .filter((item) => item.previewUrl)
          .map((item) => ({
            id: `itunes-${item.trackId}`,
            title: item.trackName,
            artist: item.artistName,
            album: item.collectionName || 'Single',
            duration: Math.round((item.trackTimeMillis || 30000) / 1000),
            cover: item.artworkUrl100 ? item.artworkUrl100.replace('100x100bb', '600x600bb') : generateGradientCover(item.trackName),
            audioUrl: item.previewUrl,
            genre: item.primaryGenreName || 'Pop',
            source: 'itunes'
          }));
        setCloudTracks(mapped);
        notify(`${mapped.length} resultados encontrados para "${searchQuery}"`);
      } else {
        notify('Nenhuma faixa encontrada para esta busca.', 'info');
      }
    } catch (err) {
      notify('Sem conexão ou erro ao consultar catálogo online.', 'error');
    } finally {
      setIsSearchingOnline(false);
    }
  };

  // ============================================================================
  // 12. EXTRATOR DE LINKS / STREAM DIRETO
  // ============================================================================
  const handleExtractStream = async (e) => {
    e.preventDefault();
    if (!extractorInput.trim()) return;
    setIsExtracting(true);

    try {
      let streamUrl = extractorInput.trim();
      let title = extractorTitle.trim() || 'Faixa Extraída Muka';
      let artist = extractorArtist.trim() || 'Muka Extractor';

      if (backendApiUrl.trim() && (streamUrl.includes('youtube.com') || streamUrl.includes('youtu.be') || streamUrl.includes('soundcloud.com'))) {
        const endpoint = `${backendApiUrl.replace(/\/$/, '')}/extract?url=${encodeURIComponent(streamUrl)}`;
        const res = await fetch(endpoint);
        const json = await res.json();
        if (json.audioUrl) {
          streamUrl = json.audioUrl;
          title = json.title || title;
          artist = json.artist || artist;
        }
      }

      const extractedTrack = {
        id: `ext-${Date.now()}`,
        title,
        artist,
        album: 'Muka Link Extractor',
        duration: 240,
        cover: generateGradientCover(title),
        audioUrl: streamUrl,
        genre: 'Web Stream',
        source: 'extractor'
      };

      setCloudTracks((prev) => [extractedTrack, ...prev]);
      selectAndPlayTrack(extractedTrack, [extractedTrack, ...queue]);
      setExtractorInput('');
      setExtractorTitle('');
      setExtractorArtist('');
      notify('Link de áudio carregado e tocando agora! 🚀');
    } catch (err) {
      notify('Erro ao extrair link. Verifique sua API de Backend.', 'error');
    } finally {
      setIsExtracting(false);
    }
  };

  // ============================================================================
  // 13. FAVORITOS, PLAYLISTS E PONTO DE CONTINUIDADE (BACKUP JSON)
  // ============================================================================
  const toggleFavorite = (id) => {
    setFavorites((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const createPlaylist = (e) => {
    e.preventDefault();
    if (!newPlaylistName.trim()) return;
    const pl = { id: `pl-${Date.now()}`, name: newPlaylistName.trim(), trackIds: [] };
    setPlaylists((prev) => [...prev, pl]);
    setNewPlaylistName('');
    notify(`Playlist "${pl.name}" criada!`);
  };

  const addTrackToPlaylist = (playlistId, trackId) => {
    setPlaylists((prev) =>
      prev.map((pl) =>
        pl.id === playlistId && !pl.trackIds.includes(trackId)
          ? { ...pl, trackIds: [...pl.trackIds, trackId] }
          : pl
      )
    );
    setPlaylistModalTrack(null);
    notify('Faixa adicionada à playlist! ✨');
  };

  const exportProjectContinuityJson = () => {
    const snapshot = {
      project: 'MukaFlow Pro Hybrid APK',
      version: '2.0.0-antigravity-ready',
      exportedAt: new Date().toISOString(),
      favorites,
      playlists,
      eqPreset,
      eqGains,
      backendApiUrl,
      localTracksMetadata: localTracks.map(({ audioUrl, ...rest }) => rest),
      offlineTracksMetadata: offlineTracks.map(({ audioUrl, audioBlob, ...rest }) => rest)
    };
    const blob = new Blob([JSON.stringify(snapshot, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'mukaflow-pro-continuity-state.json';
    a.click();
    notify('Snapshot de Continuidade (.JSON) exportado com sucesso!');
  };

  const copyCodeBlock = (key, text) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    notify('Copiado para a área de transferência!');
    setTimeout(() => setCopiedKey(''), 2500);
  };

  // Helpers de formatação
  const formatSecs = (s) => {
    if (!s || isNaN(s)) return '0:00';
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${m}:${sec < 10 ? '0' : ''}${sec}`;
  };

  const formatBytes = (bytes = 0) => {
    if (!bytes) return '3.8 MB';
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const filteredLocalTracks = localTracks.filter(
    (t) =>
      t.title.toLowerCase().includes(localSearch.toLowerCase()) ||
      t.artist.toLowerCase().includes(localSearch.toLowerCase()) ||
      (t.album && t.album.toLowerCase().includes(localSearch.toLowerCase()))
  );

  // ============================================================================
  // 14. RENDERIZAÇÃO DA INTERFACE MOBILE-FIRST
  // ============================================================================
  return (
    <div
      className="min-h-screen bg-[#07070b] text-zinc-100 flex flex-col font-sans select-none overflow-x-hidden"
      onDragOver={(e) => { e.preventDefault(); setIsDraggingOver(true); }}
      onDragLeave={() => setIsDraggingOver(false)}
      onDrop={handleDropFiles}
    >
      {/* Elemento Nativo de Áudio HTML5 */}
      <audio
        ref={audioRef}
        crossOrigin="anonymous"
        onTimeUpdate={() => setCurrentTime(audioRef.current?.currentTime || 0)}
        onLoadedMetadata={() => setDuration(audioRef.current?.duration || currentTrack?.duration || 0)}
        onEnded={handleNext}
      />

      {/* Inputs Ocultos para Importação de Arquivos Locais e Pastas Inteiras */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept="audio/*,.mp3,.m4a,.wav,.flac,.ogg,.aac"
        className="hidden"
        onChange={(e) => processLocalAudioFiles(e.target.files)}
      />
      <input
        ref={folderInputRef}
        type="file"
        webkitdirectory=""
        directory=""
        multiple
        className="hidden"
        onChange={(e) => processLocalAudioFiles(e.target.files)}
      />

      {/* Overlay de Drag & Drop Global */}
      {isDraggingOver && (
        <div className="fixed inset-0 z-50 bg-violet-950/90 backdrop-blur-md border-4 border-dashed border-violet-400 flex flex-col items-center justify-center p-6 text-center">
          <FolderOpen className="w-20 h-20 text-violet-300 animate-bounce mb-4" />
          <h2 className="text-2xl font-bold text-white">Solte suas músicas ou pastas aqui!</h2>
          <p className="text-violet-200 mt-1">Leitura instantânea de tags ID3v2, capas e armazenamento local</p>
        </div>
      )}

      {/* Notificação Toast Flutuante */}
      {toast && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2.5 px-4 py-3 rounded-2xl bg-zinc-900/95 border border-violet-500/40 shadow-2xl shadow-violet-950/50 backdrop-blur-md max-w-sm w-[92%] animate-fade-in">
          <CheckCircle2 className="w-5 h-5 text-violet-400 shrink-0" />
          <span className="text-xs sm:text-sm font-medium text-zinc-100">{toast.msg}</span>
        </div>
      )}

      {/* TOP HEADER */}
      <header className="sticky top-0 z-30 bg-[#07070b]/85 backdrop-blur-xl border-b border-white/5 px-4 py-3.5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-violet-600 via-fuchsia-600 to-cyan-400 flex items-center justify-center shadow-lg shadow-violet-600/30">
            <Disc className={`w-6 h-6 text-white ${isPlaying ? 'animate-spin' : ''}`} style={{ animationDuration: '5s' }} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-extrabold text-base tracking-tight bg-gradient-to-r from-white via-violet-200 to-fuchsia-300 bg-clip-text text-transparent">
                MukaFlow Pro
              </h1>
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-violet-500/20 text-violet-300 border border-violet-500/30">
                v2.0 APK Ready
              </span>
            </div>
            <p className="text-[11px] text-zinc-400 flex items-center gap-2">
              <span>{localTracks.length} locais</span>
              <span>•</span>
              <span>{offlineTracks.length} offline</span>
              {sleepRemainingSec > 0 && (
                <>
                  <span>•</span>
                  <span className="text-amber-400 flex items-center gap-1">
                    <Moon className="w-3 h-3" /> {formatSecs(sleepRemainingSec)}
                  </span>
                </>
              )}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-violet-600/20 hover:bg-violet-600/30 border border-violet-500/30 text-violet-200 text-xs font-semibold transition"
            title="Importar MP3 do Dispositivo"
          >
            <FolderOpen className="w-4 h-4 text-violet-400" />
            <span className="hidden sm:inline">Abrir MP3 Local</span>
          </button>
          <button
            onClick={() => {
              setShowFullPlayer(true);
              setPlayerSubView('eq');
            }}
            className="p-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-white/10 text-zinc-300"
            title="Equalizador 5 Bandas"
          >
            <Sliders className="w-4 h-4 text-fuchsia-400" />
          </button>
        </div>
      </header>

      {/* CONTEÚDO PRINCIPAL */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-4 pt-4 pb-44">
        {/* ===================================================================
            ABA 1: EXPLORAR & BUSCA ONLINE
        =================================================================== */}
        {activeTab === 'explore' && (
          <div className="space-y-6">
            {/* Banner Principal Interativo */}
            <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-violet-900/60 via-fuchsia-900/40 to-zinc-900 border border-white/10 p-5 sm:p-6">
              <div className="relative z-10 max-w-lg space-y-2">
                <span className="inline-flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full bg-white/10 text-violet-200">
                  <Sparkles className="w-3.5 h-3.5 text-fuchsia-400" /> Streaming + Memória Local + Offline
                </span>
                <h2 className="text-xl sm:text-2xl font-extrabold text-white leading-tight">
                  Ouça da nuvem, baixe sem internet ou escaneie as músicas do seu celular.
                </h2>
                <p className="text-xs sm:text-sm text-zinc-300">
                  Player híbrido com leitor ID3v2 nativo, equalizador WebAudio de 5 bandas e ponto de continuidade pronto para o Antigravity.
                </p>
                <div className="pt-2 flex flex-wrap gap-2.5">
                  <button
                    onClick={() => setActiveTab('local')}
                    className="px-4 py-2.5 rounded-xl bg-white text-zinc-950 font-bold text-xs flex items-center gap-2 shadow-lg hover:bg-violet-100 transition"
                  >
                    <HardDrive className="w-4 h-4 text-violet-700" />
                    Gerenciar Músicas Locais ({localTracks.length})
                  </button>
                  <button
                    onClick={() => setActiveTab('handoff')}
                    className="px-4 py-2.5 rounded-xl bg-violet-600/30 border border-violet-400/40 text-white font-semibold text-xs flex items-center gap-2 hover:bg-violet-600/50 transition"
                  >
                    <Smartphone className="w-4 h-4 text-fuchsia-300" />
                    Ponto de Continuidade Antigravity
                  </button>
                </div>
              </div>
            </div>

            {/* Barra de Busca Integrada */}
            <form onSubmit={searchOnlineMusic} className="relative flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Buscar artista, música ou álbum na nuvem..."
                  className="w-full pl-10 pr-24 py-3.5 rounded-2xl bg-zinc-900/90 border border-white/10 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-violet-500"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => {
                      setSearchQuery('');
                      setCloudTracks(DEMO_CATALOG);
                    }}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-zinc-400 hover:text-white"
                  >
                    Limpar
                  </button>
                )}
              </div>
              <button
                type="submit"
                disabled={isSearchingOnline}
                className="px-5 py-3.5 rounded-2xl bg-gradient-to-r from-violet-600 to-fuchsia-600 font-bold text-xs sm:text-sm text-white shadow-lg shadow-violet-600/25 flex items-center gap-2"
              >
                {isSearchingOnline ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                <span>Buscar</span>
              </button>
            </form>

            {/* Lista de Músicas do Catálogo / Busca */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-zinc-200 flex items-center gap-2">
                  <Flame className="w-4 h-4 text-fuchsia-400" />
                  {searchQuery ? `Resultados para "${searchQuery}"` : 'Catálogo Muka Cloud & Demos Completas'}
                </h3>
                <span className="text-xs text-zinc-500">{cloudTracks.length} faixas</span>
              </div>

              <div className="grid grid-cols-1 gap-2.5">
                {cloudTracks.map((track) => {
                  const isCurrent = currentTrack?.id === track.id;
                  const isSaved = offlineTracks.some((t) => t.id === track.id);
                  const isDownloading = downloadingIds[track.id];
                  const isFav = favorites.includes(track.id);

                  return (
                    <div
                      key={track.id}
                      className={`group flex items-center justify-between p-3 rounded-2xl border transition ${
                        isCurrent
                          ? 'bg-violet-950/40 border-violet-500/50 shadow-lg shadow-violet-950/30'
                          : 'bg-zinc-900/60 border-white/5 hover:bg-zinc-900 hover:border-white/10'
                      }`}
                    >
                      <div
                        onClick={() => selectAndPlayTrack(track, cloudTracks)}
                        className="flex items-center gap-3.5 flex-1 min-w-0 cursor-pointer"
                      >
                        <div className="relative w-13 h-13 sm:w-14 sm:h-14 rounded-xl overflow-hidden shrink-0 bg-zinc-800">
                          <img src={track.cover} alt={track.title} className="w-full h-full object-cover" />
                          <div
                            className={`absolute inset-0 bg-black/45 flex items-center justify-center transition ${
                              isCurrent ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'
                            }`}
                          >
                            {isCurrent && isPlaying ? (
                              <Pause className="w-6 h-6 text-white fill-white" />
                            ) : (
                              <Play className="w-6 h-6 text-white fill-white ml-0.5" />
                            )}
                          </div>
                        </div>

                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2">
                            <p className={`font-bold text-sm truncate ${isCurrent ? 'text-violet-300' : 'text-white'}`}>
                              {track.title}
                            </p>
                            {isSaved && (
                              <span className="px-1.5 py-0.5 text-[10px] font-bold rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 shrink-0">
                                OFFLINE
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-zinc-400 truncate">{track.artist}</p>
                          <div className="flex items-center gap-2 mt-1 text-[10px] text-zinc-500">
                            <span>{track.genre || 'Music'}</span>
                            <span>•</span>
                            <span>{formatSecs(track.duration)}</span>
                          </div>
                        </div>
                      </div>

                      {/* Ações da Faixa */}
                      <div className="flex items-center gap-1 sm:gap-1.5 ml-2">
                        <button
                          onClick={() => toggleFavorite(track.id)}
                          className={`p-2 rounded-xl transition ${
                            isFav ? 'text-pink-500 bg-pink-500/10' : 'text-zinc-400 hover:text-white hover:bg-white/5'
                          }`}
                          title="Favoritar"
                        >
                          <Heart className={`w-4 h-4 ${isFav ? 'fill-pink-500' : ''}`} />
                        </button>

                        <button
                          onClick={() => setPlaylistModalTrack(track)}
                          className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-white/5"
                          title="Adicionar à Playlist"
                        >
                          <Plus className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => handleDownloadOffline(track)}
                          disabled={isDownloading}
                          className={`p-2.5 rounded-xl font-semibold text-xs flex items-center gap-1 transition ${
                            isSaved
                              ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                              : 'bg-violet-600/20 hover:bg-violet-600 text-violet-300 hover:text-white border border-violet-500/30'
                          }`}
                          title="Baixar para ouvir Offline"
                        >
                          {isDownloading ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : isSaved ? (
                            <CheckCircle2 className="w-4 h-4" />
                          ) : (
                            <Download className="w-4 h-4" />
                          )}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* ===================================================================
            ABA 2: ARMAZENAMENTO LOCAL (SCANNER DE PASTAS + LEITOR ID3v2)
        =================================================================== */}
        {activeTab === 'local' && (
          <div className="space-y-6">
            {/* Painel de Importação de Arquivos Locais e Pastas */}
            <div className="rounded-3xl bg-gradient-to-br from-zinc-900 via-violet-950/30 to-zinc-900 border border-violet-500/30 p-5 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <span className="inline-flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-violet-300">
                    <HardDrive className="w-3.5 h-3.5" /> Scanner de Memória Local + Parser ID3v2
                  </span>
                  <h2 className="text-lg sm:text-xl font-extrabold text-white">
                    Toque músicas salvas no seu celular ou computador
                  </h2>
                  <p className="text-xs text-zinc-400">
                    Suporta <strong>.MP3, .M4A, .WAV, .FLAC e .OGG</strong>. Extrai automaticamente capa embutida, artista, álbum e grava no banco local do APK.
                  </p>
                </div>

                <div className="flex flex-wrap gap-2 shrink-0">
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="px-4 py-3 rounded-2xl bg-violet-600 hover:bg-violet-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-violet-600/30 transition"
                  >
                    <FileAudio className="w-4 h-4" />
                    Importar Arquivos MP3
                  </button>
                  <button
                    onClick={() => folderInputRef.current?.click()}
                    className="px-4 py-3 rounded-2xl bg-zinc-800 hover:bg-zinc-700 border border-white/10 text-zinc-100 font-bold text-xs flex items-center gap-2 transition"
                  >
                    <FolderOpen className="w-4 h-4 text-fuchsia-400" />
                    Escanear Pasta Inteira
                  </button>
                </div>
              </div>

              {/* Barra de Progresso do Scanner ID3 */}
              {isScanningLocal && (
                <div className="p-3.5 rounded-2xl bg-black/40 border border-violet-500/30 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-violet-300 font-semibold flex items-center gap-2">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Lendo tags ID3v2 e capas dos arquivos...
                    </span>
                    <span className="text-zinc-400 font-mono">
                      {scanProgress.done} / {scanProgress.total}
                    </span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-zinc-800 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-violet-500 to-fuchsia-500 transition-all"
                      style={{
                        width: `${scanProgress.total ? (scanProgress.done / scanProgress.total) * 100 : 0}%`
                      }}
                    />
                  </div>
                </div>
              )}

              {/* Opção de Persistência no IndexedDB */}
              <div className="flex items-center justify-between pt-2 border-t border-white/5 text-xs">
                <label className="flex items-center gap-2 text-zinc-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={persistLocalToIDB}
                    onChange={(e) => setPersistLocalToIDB(e.target.checked)}
                    className="rounded accent-violet-600"
                  />
                  <span>Manter arquivos importados salvos permanentemente no banco interno do App (IndexedDB)</span>
                </label>
                <span className="text-zinc-500 hidden sm:inline">Arraste e solte arquivos em qualquer lugar</span>
              </div>
            </div>

            {/* Filtros Internos da Biblioteca Local */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-1.5 bg-zinc-900/90 p-1 rounded-2xl border border-white/5 w-fit">
                {[
                  { id: 'all', label: `Músicas (${localTracks.length})` },
                  { id: 'playlists', label: `Playlists (${playlists.length})` },
                  { id: 'favorites', label: `Favoritas (${favorites.length})` }
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setLocalFilter(tab.id)}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition ${
                      localFilter === tab.id
                        ? 'bg-violet-600 text-white shadow'
                        : 'text-zinc-400 hover:text-white'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              <div className="relative flex-1 max-w-xs">
                <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={localSearch}
                  onChange={(e) => setLocalSearch(e.target.value)}
                  placeholder="Filtrar biblioteca local..."
                  className="w-full pl-8 pr-3 py-2 rounded-xl bg-zinc-900 border border-white/10 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-violet-500"
                />
              </div>
            </div>

            {/* Sub-aba: Lista de Arquivos Locais */}
            {localFilter === 'all' && (
              <>
                {filteredLocalTracks.length === 0 ? (
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="cursor-pointer rounded-3xl border-2 border-dashed border-zinc-800 hover:border-violet-500/50 bg-zinc-900/30 p-10 text-center space-y-3 transition"
                  >
                    <div className="w-16 h-16 rounded-2xl bg-violet-600/10 border border-violet-500/20 flex items-center justify-center mx-auto">
                      <FolderOpen className="w-8 h-8 text-violet-400" />
                    </div>
                    <h3 className="text-base font-bold text-white">Nenhuma música local importada ainda</h3>
                    <p className="text-xs text-zinc-400 max-w-md mx-auto">
                      Clique aqui para escolher arquivos <strong>.MP3, .M4A, .WAV ou .FLAC</strong> da memória do seu dispositivo ou arraste uma pasta de músicas para a tela.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {filteredLocalTracks.map((track) => {
                      const isCurrent = currentTrack?.id === track.id;
                      return (
                        <div
                          key={track.id}
                          className={`flex items-center justify-between p-3 rounded-2xl border transition ${
                            isCurrent
                              ? 'bg-violet-950/40 border-violet-500/50'
                              : 'bg-zinc-900/60 border-white/5 hover:bg-zinc-900'
                          }`}
                        >
                          <div
                            onClick={() => selectAndPlayTrack(track, filteredLocalTracks)}
                            className="flex items-center gap-3.5 flex-1 min-w-0 cursor-pointer"
                          >
                            <img
                              src={track.cover}
                              alt={track.title}
                              className="w-13 h-13 rounded-xl object-cover shrink-0 bg-zinc-800"
                            />
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-2">
                                <p className={`font-bold text-sm truncate ${isCurrent ? 'text-violet-300' : 'text-white'}`}>
                                  {track.title}
                                </p>
                                <span className="px-1.5 py-0.5 text-[10px] font-bold rounded bg-fuchsia-500/20 text-fuchsia-300 border border-fuchsia-500/30">
                                  LOCAL
                                </span>
                              </div>
                              <p className="text-xs text-zinc-400 truncate">
                                {track.artist} • <span className="text-zinc-500">{track.album}</span>
                              </p>
                              <div className="flex items-center gap-2 mt-0.5 text-[10px] text-zinc-500">
                                <span>{track.genre}</span>
                                <span>•</span>
                                <span>{formatBytes(track.fileSize)}</span>
                                <span>•</span>
                                <span>{formatSecs(track.duration)}</span>
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => setPlaylistModalTrack(track)}
                              className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-white/5"
                              title="Adicionar à Playlist"
                            >
                              <Plus className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => removeLocalTrack(track.id)}
                              className="p-2 rounded-xl text-zinc-500 hover:text-rose-400 hover:bg-rose-500/10"
                              title="Remover da biblioteca"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </>
            )}

            {/* Sub-aba: Playlists Customizadas */}
            {localFilter === 'playlists' && (
              <div className="space-y-4">
                <form onSubmit={createPlaylist} className="flex gap-2">
                  <input
                    type="text"
                    value={newPlaylistName}
                    onChange={(e) => setNewPlaylistName(e.target.value)}
                    placeholder="Nome da nova playlist (ex: Funk 2026, Viagem)..."
                    className="flex-1 px-4 py-3 rounded-2xl bg-zinc-900 border border-white/10 text-xs text-white focus:outline-none focus:border-violet-500"
                  />
                  <button
                    type="submit"
                    className="px-4 py-3 rounded-2xl bg-violet-600 hover:bg-violet-500 text-white font-bold text-xs flex items-center gap-1.5"
                  >
                    <FolderPlus className="w-4 h-4" /> Criar Playlist
                  </button>
                </form>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {playlists.map((pl) => {
                    const allKnown = [...localTracks, ...offlineTracks, ...cloudTracks];
                    const plTracks = pl.trackIds
                      .map((id) => allKnown.find((t) => t.id === id))
                      .filter(Boolean);

                    return (
                      <div
                        key={pl.id}
                        className="p-4 rounded-2xl bg-zinc-900/70 border border-white/10 flex flex-col justify-between gap-3"
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="font-bold text-sm text-white">{pl.name}</h4>
                            <p className="text-xs text-zinc-400">{plTracks.length} faixas salvas</p>
                          </div>
                          {plTracks.length > 0 && (
                            <button
                              onClick={() => selectAndPlayTrack(plTracks[0], plTracks)}
                              className="px-3 py-2 rounded-xl bg-violet-600 text-white text-xs font-bold flex items-center gap-1.5"
                            >
                              <Play className="w-3.5 h-3.5 fill-white" /> Tocar
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Sub-aba: Favoritas */}
            {localFilter === 'favorites' && (
              <div className="space-y-2">
                {[...localTracks, ...offlineTracks, ...cloudTracks]
                  .filter((t, idx, arr) => favorites.includes(t.id) && arr.findIndex((x) => x.id === t.id) === idx)
                  .map((track) => (
                    <div
                      key={track.id}
                      onClick={() => selectAndPlayTrack(track)}
                      className="flex items-center justify-between p-3 rounded-2xl bg-zinc-900/60 border border-white/5 hover:bg-zinc-900 cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <img src={track.cover} alt={track.title} className="w-12 h-12 rounded-xl object-cover" />
                        <div>
                          <p className="font-bold text-sm text-white">{track.title}</p>
                          <p className="text-xs text-zinc-400">{track.artist}</p>
                        </div>
                      </div>
                      <Heart className="w-4 h-4 text-pink-500 fill-pink-500 mr-2" />
                    </div>
                  ))}
              </div>
            )}
          </div>
        )}

        {/* ===================================================================
            ABA 3: COFRE OFFLINE (INDEXEDDB PERSISTENTE + EXPORTAR MP3)
        =================================================================== */}
        {activeTab === 'offline' && (
          <div className="space-y-5">
            <div className="p-5 rounded-3xl bg-gradient-to-r from-emerald-950/60 via-teal-950/40 to-zinc-900 border border-emerald-500/30 flex items-center justify-between">
              <div className="space-y-1">
                <span className="inline-flex items-center gap-1.5 text-[11px] font-bold uppercase text-emerald-300">
                  <WifiOff className="w-3.5 h-3.5" /> Cofre Offline IndexedDB
                </span>
                <h2 className="text-lg font-extrabold text-white">
                  Músicas Baixadas ({offlineTracks.length})
                </h2>
                <p className="text-xs text-zinc-300">
                  Estas músicas estão gravadas diretamente no armazenamento interno do aplicativo e funcionam em Modo Avião.
                </p>
              </div>
            </div>

            {offlineTracks.length === 0 ? (
              <div className="p-10 rounded-3xl bg-zinc-900/40 border border-white/5 text-center space-y-3">
                <WifiOff className="w-10 h-10 text-zinc-500 mx-auto" />
                <p className="text-sm font-bold text-zinc-300">Seu Cofre Offline está vazio</p>
                <p className="text-xs text-zinc-500 max-w-sm mx-auto">
                  Na aba <strong>Explorar</strong>, toque no ícone de download ao lado de qualquer música para salvá-la sem internet.
                </p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {offlineTracks.map((track) => (
                  <div
                    key={track.id}
                    className="flex items-center justify-between p-3 rounded-2xl bg-zinc-900/70 border border-emerald-500/20"
                  >
                    <div
                      onClick={() => selectAndPlayTrack(track, offlineTracks)}
                      className="flex items-center gap-3.5 flex-1 min-w-0 cursor-pointer"
                    >
                      <img src={track.cover} alt={track.title} className="w-13 h-13 rounded-xl object-cover" />
                      <div className="min-w-0 flex-1">
                        <p className="font-bold text-sm text-white truncate">{track.title}</p>
                        <p className="text-xs text-zinc-400 truncate">{track.artist}</p>
                        <span className="text-[10px] text-emerald-400 font-semibold">
                          Salvo Offline • {formatBytes(track.fileSize)}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => exportMp3ToDevice(track)}
                        className="px-3 py-2 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 text-xs font-bold flex items-center gap-1"
                        title="Salvar arquivo .MP3 na pasta Downloads"
                      >
                        <Download className="w-3.5 h-3.5" /> .MP3
                      </button>
                      <button
                        onClick={() => removeOfflineTrack(track.id)}
                        className="p-2 rounded-xl text-zinc-500 hover:text-rose-400"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ===================================================================
            ABA 4: EXTRATOR DE LINKS / CONECTOR DE API EXTERNA
        =================================================================== */}
        {activeTab === 'extractor' && (
          <div className="space-y-6">
            <div className="p-5 rounded-3xl bg-zinc-900/80 border border-white/10 space-y-4">
              <div className="space-y-1">
                <span className="text-[11px] font-bold uppercase tracking-wider text-fuchsia-400 flex items-center gap-1.5">
                  <Radio className="w-3.5 h-3.5" /> Extrator de Stream Direto & API Muka
                </span>
                <h2 className="text-lg font-extrabold text-white">
                  Adicionar Música via Link Direto ou Backend Extrator
                </h2>
                <p className="text-xs text-zinc-400">
                  Cole um link direto de áudio (`.mp3`, `.m4a`, `.ogg`) ou conecte seu servidor Node.js/yt-dlp no Antigravity para extrair do YouTube/SoundCloud.
                </p>
              </div>

              <form onSubmit={handleExtractStream} className="space-y-3">
                <input
                  type="url"
                  required
                  value={extractorInput}
                  onChange={(e) => setExtractorInput(e.target.value)}
                  placeholder="https://exemplo.com/musica.mp3 ou link do YouTube..."
                  className="w-full px-4 py-3 rounded-2xl bg-black/50 border border-white/10 text-xs sm:text-sm text-white focus:outline-none focus:border-violet-500"
                />
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    value={extractorTitle}
                    onChange={(e) => setExtractorTitle(e.target.value)}
                    placeholder="Título da Faixa (opcional)"
                    className="px-4 py-3 rounded-2xl bg-black/50 border border-white/10 text-xs text-white focus:outline-none focus:border-violet-500"
                  />
                  <input
                    type="text"
                    value={extractorArtist}
                    onChange={(e) => setExtractorArtist(e.target.value)}
                    placeholder="Artista (opcional)"
                    className="px-4 py-3 rounded-2xl bg-black/50 border border-white/10 text-xs text-white focus:outline-none focus:border-violet-500"
                  />
                </div>
                <button
                  type="submit"
                  disabled={isExtracting}
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-violet-600 to-fuchsia-600 font-bold text-xs sm:text-sm text-white shadow-lg flex items-center justify-center gap-2"
                >
                  {isExtracting ? <Loader2 className="w-4 h-4 animate-spin" /> : <PlusCircle className="w-4 h-4" />}
                  Carregar e Tocar Stream Agora
                </button>
              </form>

              <div className="pt-4 border-t border-white/5 space-y-2">
                <label className="text-xs font-bold text-zinc-300 block">
                  Endpoint do Seu Backend Extrator (Para configurar no Antigravity):
                </label>
                <div className="flex gap-2">
                  <input
                    type="url"
                    value={backendApiUrl}
                    onChange={(e) => {
                      setBackendApiUrl(e.target.value);
                      localStorage.setItem('muka_pro_api', e.target.value);
                    }}
                    placeholder="https://sua-api-muka.vercel.app/api"
                    className="flex-1 px-3.5 py-2.5 rounded-xl bg-black/40 border border-white/10 text-xs text-zinc-200"
                  />
                  <button
                    type="button"
                    onClick={() => notify('Endpoint de extração salvo!')}
                    className="px-4 py-2.5 rounded-xl bg-zinc-800 text-xs font-bold text-violet-300"
                  >
                    Salvar
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ===================================================================
            ABA 5: PONTO DE CONTINUIDADE ANTIGRAVITY & BUILD APK GITHUB
        =================================================================== */}
        {activeTab === 'handoff' && (
          <div className="space-y-6">
            {/* Cabeçalho do Ponto de Continuidade */}
            <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-br from-violet-950/70 via-zinc-900 to-fuchsia-950/40 border border-violet-500/40 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    Checkpoint de Transferência Pronto
                  </span>
                  <h2 className="text-xl font-extrabold text-white mt-2">
                    Ponto de Continuidade ➔ Antigravity & GitHub APK
                  </h2>
                  <p className="text-xs text-zinc-300 mt-1">
                    Tudo o que você precisa para continuar este projeto no Antigravity e compilar o arquivo <code>.apk</code> automaticamente no GitHub Actions.
                  </p>
                </div>
                <button
                  onClick={exportProjectContinuityJson}
                  className="px-4 py-3 rounded-2xl bg-white text-zinc-950 font-extrabold text-xs flex items-center gap-2 shadow-lg shrink-0 hover:bg-violet-100 transition"
                >
                  <Archive className="w-4 h-4 text-violet-700" />
                  Exportar Backup JSON
                </button>
              </div>

              {/* Checklist de Arquitetura Concluída */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2 text-xs">
                {[
                  'Player Completo + Fila + Shuffle/Repeat + Velocidade (0.75x - 1.5x)',
                  'Leitor de Armazenamento Local (Arquivos e Pastas) com Parser ID3v2 + Capas',
                  'Equalizador Real de 5 Bandas via Web Audio API + 6 Presets + Visualizer',
                  'Cofre Offline Persistente com IndexedDB + Exportador direto de .MP3',
                  'Sleep Timer Automático + Controles na Tela de Bloqueio (MediaSession)',
                  'Configuração Capacitor Android + Permissões de Áudio + Workflow GitHub APK'
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-2 p-2.5 rounded-xl bg-black/40 border border-white/5 text-zinc-200">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* BLOCO 1: PROMPT DE CONTINUIDADE PARA COLAR NO ANTIGRAVITY */}
            <div className="p-5 rounded-3xl bg-zinc-900/80 border border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-violet-400" />
                    1. Prompt de Continuidade para colar no Antigravity
                  </h3>
                  <p className="text-xs text-zinc-400">
                    Quando abrir o projeto no Antigravity, cole este prompt para o agente assumir exatamente de onde paramos:
                  </p>
                </div>
                <button
                  onClick={() =>
                    copyCodeBlock(
                      'prompt',
                      `Estou trazendo o código base do MukaFlow Pro (React + Tailwind + Lucide + IndexedDB + Web Audio API 5-Band EQ + Leitor Local ID3v2).\n\nO frontend já está 100% funcional em src/App.jsx com:\n1. Reprodução de arquivos locais (.mp3, .m4a, .wav, .flac) com parser binário ID3v2 e leitura de pastas.\n2. Cofre Offline via IndexedDB (MukaFlowProDB).\n3. Equalizador de 5 bandas e Sleep Timer.\n\nPróximos passos que quero executar agora no Antigravity:\n1. Inicializar o projeto Vite + Capacitor Android (@capacitor/core, @capacitor/cli, @capacitor/android, @capacitor/filesystem).\n2. Adicionar as permissões READ_MEDIA_AUDIO e READ_EXTERNAL_STORAGE no AndroidManifest.xml.\n3. Criar uma rota de backend Node.js (/api/extract) com yt-dlp para conectar no campo 'Endpoint Extrator' do app.\n4. Configurar o workflow .github/workflows/build-apk.yml para compilar o APK automaticamente no GitHub.`
                    )
                  }
                  className="px-3 py-2 rounded-xl bg-violet-600/20 border border-violet-500/30 text-violet-300 text-xs font-bold flex items-center gap-1.5"
                >
                  {copiedKey === 'prompt' ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  Copiar Prompt
                </button>
              </div>
              <pre className="p-4 rounded-2xl bg-black/70 border border-white/5 text-[11px] text-zinc-300 overflow-x-auto leading-relaxed font-mono">
{`Estou trazendo o código base do MukaFlow Pro (React + Tailwind + Lucide + IndexedDB + Web Audio API 5-Band EQ + Leitor Local ID3v2).

O frontend já está 100% funcional em src/App.jsx com:
1. Reprodução de arquivos locais (.mp3, .m4a, .wav, .flac) com parser binário ID3v2 e leitura de pastas.
2. Cofre Offline via IndexedDB (MukaFlowProDB).
3. Equalizador de 5 bandas e Sleep Timer.

Próximos passos que quero executar agora no Antigravity:
1. Inicializar o projeto Vite + Capacitor Android (@capacitor/core, @capacitor/cli, @capacitor/android, @capacitor/filesystem).
2. Adicionar as permissões READ_MEDIA_AUDIO e READ_EXTERNAL_STORAGE no AndroidManifest.xml.
3. Criar uma rota de backend Node.js (/api/extract) com yt-dlp para conectar no campo 'Endpoint Extrator' do app.
4. Configurar o workflow .github/workflows/build-apk.yml para compilar o APK automaticamente no GitHub.`}
              </pre>
            </div>

            {/* BLOCO 2: PERMISSÕES ANDROID MANIFEST PARA LEITURA DE MÚSICAS LOCAIS */}
            <div className="p-5 rounded-3xl bg-zinc-900/80 border border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Layers className="w-4 h-4 text-fuchsia-400" />
                    2. Permissões de Armazenamento Local (android/app/src/main/AndroidManifest.xml)
                  </h3>
                  <p className="text-xs text-zinc-400">
                    Garante que o APK no Android 10, 11, 12, 13 e 14+ possa ler todas as pastas de músicas do celular:
                  </p>
                </div>
                <button
                  onClick={() =>
                    copyCodeBlock(
                      'manifest',
                      `<uses-permission android:name="android.permission.INTERNET" />\n<uses-permission android:name="android.permission.READ_MEDIA_AUDIO" />\n<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />\n<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />\n<uses-permission android:name="android.permission.WAKE_LOCK" />`
                    )
                  }
                  className="px-3 py-2 rounded-xl bg-zinc-800 text-zinc-200 text-xs font-bold flex items-center gap-1.5"
                >
                  {copiedKey === 'manifest' ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  Copiar XML
                </button>
              </div>
              <pre className="p-4 rounded-2xl bg-black/70 border border-white/5 text-[11px] text-emerald-300 overflow-x-auto font-mono">
{`<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.READ_MEDIA_AUDIO" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
<uses-permission android:name="android.permission.WAKE_LOCK" />`}
              </pre>
            </div>

            {/* BLOCO 3: GITHUB ACTIONS WORKFLOW PARA GERAR O APK */}
            <div className="p-5 rounded-3xl bg-zinc-900/80 border border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-cyan-400" />
                    3. Workflow GitHub Actions (.github/workflows/build-apk.yml)
                  </h3>
                  <p className="text-xs text-zinc-400">
                    Compila o projeto na nuvem do GitHub e disponibiliza o <code>MukaFlow-Pro-Debug.apk</code> pronto para baixar:
                  </p>
                </div>
                <button
                  onClick={() =>
                    copyCodeBlock(
                      'workflow',
                      `name: Build MukaFlow Pro Android APK\non:\n  push:\n    branches: [ main, master ]\n  workflow_dispatch:\n\njobs:\n  build-android:\n    runs-on: ubuntu-latest\n    steps:\n      - uses: actions/checkout@v4\n      - uses: actions/setup-node@v4\n        with:\n          node-version: 20\n      - uses: actions/setup-java@v4\n        with:\n          distribution: 'temurin'\n          java-version: '17'\n      - name: Install & Build Web Assets\n        run: |\n          npm install\n          npm run build\n          npx cap sync android\n      - name: Assemble Debug APK\n        working-directory: ./android\n        run: |\n          chmod +x gradlew\n          ./gradlew assembleDebug\n      - name: Upload APK Artifact\n        uses: actions/upload-artifact@v4\n        with:\n          name: MukaFlow-Pro-APK\n          path: android/app/build/outputs/apk/debug/app-debug.apk`
                    )
                  }
                  className="px-3 py-2 rounded-xl bg-zinc-800 text-zinc-200 text-xs font-bold flex items-center gap-1.5"
                >
                  {copiedKey === 'workflow' ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  Copiar Workflow
                </button>
              </div>
              <pre className="p-4 rounded-2xl bg-black/70 border border-white/5 text-[11px] text-cyan-300 overflow-x-auto font-mono">
{`name: Build MukaFlow Pro Android APK
on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build-android:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
      - uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '17'
      - name: Install & Build Web Assets
        run: |
          npm install
          npm run build
          npx cap sync android
      - name: Assemble Debug APK
        working-directory: ./android
        run: |
          chmod +x gradlew
          ./gradlew assembleDebug
      - name: Upload APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: MukaFlow-Pro-APK
          path: android/app/build/outputs/apk/debug/app-debug.apk`}
              </pre>
            </div>
          </div>
        )}
      </main>

      {/* =====================================================================
          MODAL ADICIONAR À PLAYLIST
      ===================================================================== */}
      {playlistModalTrack && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-white/10 rounded-3xl max-w-sm w-full p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-white">Adicionar à Playlist</h3>
              <button onClick={() => setPlaylistModalTrack(null)} className="text-zinc-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-xs text-zinc-400 truncate">
              Faixa: <strong className="text-white">{playlistModalTrack.title}</strong>
            </p>
            <div className="space-y-2 max-h-56 overflow-y-auto">
              {playlists.map((pl) => (
                <button
                  key={pl.id}
                  onClick={() => addTrackToPlaylist(pl.id, playlistModalTrack.id)}
                  className="w-full p-3 rounded-2xl bg-zinc-800/80 hover:bg-violet-600/30 border border-white/5 text-left flex items-center justify-between transition"
                >
                  <span className="text-xs font-bold text-white">{pl.name}</span>
                  <span className="text-[10px] text-zinc-400">{pl.trackIds.length} faixas</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          PLAYER TELA CHEIA + EQUALIZADOR 5 BANDAS + FILA + SLEEP TIMER
      ===================================================================== */}
      {showFullPlayer && currentTrack && (
        <div className="fixed inset-0 z-50 bg-gradient-to-b from-[#120924] via-[#090910] to-[#050508] flex flex-col justify-between p-5 sm:p-8 overflow-y-auto">
          {/* Topo do Player Expandido */}
          <div className="flex items-center justify-between max-w-lg w-full mx-auto">
            <button
              onClick={() => setShowFullPlayer(false)}
              className="p-2.5 rounded-2xl bg-white/5 hover:bg-white/10 text-zinc-200"
            >
              <ChevronDown className="w-6 h-6" />
            </button>

            <div className="flex items-center gap-1 bg-zinc-900/90 p-1 rounded-2xl border border-white/10">
              {[
                { id: 'cover', label: 'Player' },
                { id: 'eq', label: 'Equalizador' },
                { id: 'queue', label: `Fila (${queue.length})` }
              ].map((t) => (
                <button
                  key={t.id}
                  onClick={() => setPlayerSubView(t.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                    playerSubView === t.id ? 'bg-violet-600 text-white' : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>

            <button
              onClick={() => exportMp3ToDevice(currentTrack)}
              className="p-2.5 rounded-2xl bg-white/5 hover:bg-white/10 text-violet-300"
              title="Baixar arquivo MP3"
            >
              <Download className="w-5 h-5" />
            </button>
          </div>

          {/* Sub-View 1: Capa + Visualizador de Áudio */}
          {playerSubView === 'cover' && (
            <div className="my-auto max-w-md w-full mx-auto flex flex-col items-center text-center space-y-5 py-4">
              <div className="relative w-64 h-64 sm:w-72 sm:h-72 rounded-3xl overflow-hidden shadow-2xl shadow-violet-950/60 border border-white/10">
                <img src={currentTrack.cover} alt={currentTrack.title} className="w-full h-full object-cover" />
                {currentTrack.source === 'local-device' && (
                  <span className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-black/70 backdrop-blur-md text-[10px] font-bold text-fuchsia-300 border border-fuchsia-500/30">
                    MEMÓRIA LOCAL
                  </span>
                )}
              </div>

              {/* Canvas WebAudio Visualizer */}
              <canvas ref={canvasRef} width={280} height={42} className="w-64 h-10 opacity-85" />

              <div className="space-y-1 px-2">
                <h2 className="text-xl sm:text-2xl font-extrabold text-white line-clamp-1">{currentTrack.title}</h2>
                <p className="text-sm text-zinc-400">{currentTrack.artist} • {currentTrack.album}</p>
              </div>
            </div>
          )}

          {/* Sub-View 2: Equalizador de 5 Bandas + Velocidade + Sleep Timer */}
          {playerSubView === 'eq' && (
            <div className="my-auto max-w-md w-full mx-auto bg-zinc-900/70 border border-white/10 rounded-3xl p-5 space-y-5">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm text-white flex items-center gap-2">
                    <Sliders className="w-4 h-4 text-fuchsia-400" /> Equalizador WebAudio 5 Bandas
                  </h3>
                  <p className="text-[11px] text-zinc-400">Processamento de frequência em tempo real</p>
                </div>
                <button
                  onClick={() => applyEqPreset('flat')}
                  className="text-xs text-violet-400 hover:underline"
                >
                  Resetar
                </button>
              </div>

              {/* Presets Rápidos */}
              <div className="flex flex-wrap gap-1.5">
                {Object.entries(EQ_PRESETS).map(([key, pr]) => (
                  <button
                    key={key}
                    onClick={() => applyEqPreset(key)}
                    className={`px-2.5 py-1.5 rounded-xl text-[11px] font-bold border transition ${
                      eqPreset === key
                        ? 'bg-violet-600 text-white border-violet-400'
                        : 'bg-zinc-800/80 text-zinc-300 border-white/5 hover:bg-zinc-800'
                    }`}
                  >
                    {pr.name.split(' ')[0]}
                  </button>
                ))}
              </div>

              {/* Sliders das 5 Bandas */}
              <div className="grid grid-cols-5 gap-2 pt-2">
                {EQ_BANDS.map((band, idx) => (
                  <div key={band.freq} className="flex flex-col items-center space-y-2 bg-black/40 p-2.5 rounded-2xl border border-white/5">
                    <span className="text-[10px] font-mono text-violet-300 font-bold">
                      {eqGains[idx] > 0 ? `+${eqGains[idx]}` : eqGains[idx]}dB
                    </span>
                    <input
                      type="range"
                      min="-12"
                      max="12"
                      step="1"
                      value={eqGains[idx]}
                      onChange={(e) => updateEqBandGain(idx, e.target.value)}
                      className="w-full accent-violet-500 cursor-pointer"
                    />
                    <span className="text-[10px] font-bold text-white">{band.label}</span>
                    <span className="text-[9px] text-zinc-500">{band.desc}</span>
                  </div>
                ))}
              </div>

              {/* Velocidade de Reprodução & Sleep Timer */}
              <div className="grid grid-cols-2 gap-3 pt-2 border-t border-white/10">
                <div className="space-y-1.5">
                  <span className="text-[11px] font-bold text-zinc-300 flex items-center gap-1">
                    <Gauge className="w-3.5 h-3.5 text-cyan-400" /> Velocidade
                  </span>
                  <div className="flex gap-1">
                    {[0.75, 1.0, 1.25, 1.5].map((r) => (
                      <button
                        key={r}
                        onClick={() => changeSpeed(r)}
                        className={`flex-1 py-1.5 rounded-lg text-[10px] font-bold ${
                          playbackRate === r ? 'bg-cyan-500 text-zinc-950' : 'bg-zinc-800 text-zinc-300'
                        }`}
                      >
                        {r}x
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-1.5">
                  <span className="text-[11px] font-bold text-zinc-300 flex items-center gap-1">
                    <Moon className="w-3.5 h-3.5 text-amber-400" /> Sleep Timer
                  </span>
                  <div className="flex gap-1">
                    {[0, 15, 30, 60].map((m) => (
                      <button
                        key={m}
                        onClick={() => activateSleepTimer(m)}
                        className={`flex-1 py-1.5 rounded-lg text-[10px] font-bold ${
                          sleepTimerMinutes === m ? 'bg-amber-500 text-zinc-950' : 'bg-zinc-800 text-zinc-300'
                        }`}
                      >
                        {m === 0 ? 'Off' : `${m}m`}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Sub-View 3: Fila de Reprodução */}
          {playerSubView === 'queue' && (
            <div className="my-auto max-w-md w-full mx-auto bg-zinc-900/70 border border-white/10 rounded-3xl p-4 max-h-80 overflow-y-auto space-y-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 px-1">
                Próximas na Fila de Reprodução
              </h3>
              {queue.map((item, idx) => (
                <div
                  key={`${item.id}-${idx}`}
                  onClick={() => {
                    setCurrentIndex(idx);
                    setIsPlaying(true);
                  }}
                  className={`flex items-center justify-between p-2.5 rounded-xl cursor-pointer ${
                    idx === currentIndex ? 'bg-violet-600/30 border border-violet-500/40' : 'hover:bg-white/5'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <img src={item.cover} alt={item.title} className="w-9 h-9 rounded-lg object-cover" />
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-white truncate">{item.title}</p>
                      <p className="text-[10px] text-zinc-400 truncate">{item.artist}</p>
                    </div>
                  </div>
                  <span className="text-[10px] text-zinc-500">{formatSecs(item.duration)}</span>
                </div>
              ))}
            </div>
          )}

          {/* Controles Inferiores do Player Expandido */}
          <div className="max-w-md w-full mx-auto space-y-4">
            <div className="space-y-1.5">
              <input
                type="range"
                min="0"
                max={duration || 100}
                value={currentTime}
                onChange={handleSeek}
                className="w-full accent-violet-500 cursor-pointer h-1.5 bg-zinc-800 rounded-lg"
              />
              <div className="flex justify-between text-[11px] font-mono text-zinc-400">
                <span>{formatSecs(currentTime)}</span>
                <span>{formatSecs(duration)}</span>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <button
                onClick={() => setIsShuffle(!isShuffle)}
                className={`p-2.5 rounded-xl ${isShuffle ? 'text-violet-400 bg-violet-500/15' : 'text-zinc-400'}`}
              >
                <Shuffle className="w-5 h-5" />
              </button>

              <button onClick={handlePrev} className="p-3 rounded-2xl text-white hover:bg-white/10">
                <SkipBack className="w-7 h-7 fill-white" />
              </button>

              <button
                onClick={togglePlay}
                className="w-16 h-16 rounded-full bg-gradient-to-r from-violet-600 to-fuchsia-600 flex items-center justify-center text-white shadow-xl shadow-violet-600/40"
              >
                {isPlaying ? <Pause className="w-8 h-8 fill-white" /> : <Play className="w-8 h-8 fill-white ml-1" />}
              </button>

              <button onClick={handleNext} className="p-3 rounded-2xl text-white hover:bg-white/10">
                <SkipForward className="w-7 h-7 fill-white" />
              </button>

              <button
                onClick={() =>
                  setRepeatMode((m) => (m === 'off' ? 'all' : m === 'all' ? 'one' : 'off'))
                }
                className={`p-2.5 rounded-xl relative ${
                  repeatMode !== 'off' ? 'text-violet-400 bg-violet-500/15' : 'text-zinc-400'
                }`}
              >
                <Repeat className="w-5 h-5" />
                {repeatMode === 'one' && (
                  <span className="absolute top-1 right-1 text-[9px] font-bold text-fuchsia-300">1</span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          MINI-PLAYER FLUTUANTE + BARRA DE NAVEGAÇÃO INFERIOR (5 ABAS)
      ===================================================================== */}
      <div className="fixed bottom-0 inset-x-0 z-40 bg-gradient-to-t from-[#07070b] via-[#07070b]/95 to-transparent pt-2">
        <div className="max-w-4xl mx-auto px-3 pb-2 space-y-2">
          {/* Mini Player */}
          {currentTrack && (
            <div className="rounded-2xl bg-zinc-900/95 border border-white/10 shadow-2xl backdrop-blur-xl overflow-hidden">
              {/* Barra de Progresso Fina no Topo do Mini Player */}
              <div className="w-full h-1 bg-zinc-800">
                <div
                  className="h-full bg-gradient-to-r from-violet-500 to-fuchsia-500 transition-all"
                  style={{ width: `${duration ? Math.min(100, (currentTime / duration) * 100) : 0}%` }}
                />
              </div>

              <div className="p-2.5 flex items-center justify-between gap-3">
                <div
                  onClick={() => setShowFullPlayer(true)}
                  className="flex items-center gap-3 flex-1 min-w-0 cursor-pointer"
                >
                  <img
                    src={currentTrack.cover}
                    alt={currentTrack.title}
                    className={`w-11 h-11 rounded-xl object-cover shrink-0 ${isPlaying ? ' ring-2 ring-violet-500' : ''}`}
                  />
                  <div className="min-w-0 flex-1">
                    <p className="font-bold text-xs sm:text-sm text-white truncate">{currentTrack.title}</p>
                    <p className="text-[11px] text-zinc-400 truncate flex items-center gap-1.5">
                      <span>{currentTrack.artist}</span>
                      {currentTrack.source === 'local-device' && (
                        <span className="text-[9px] px-1.5 py-0.2 rounded bg-fuchsia-500/20 text-fuchsia-300 font-bold">
                          LOCAL
                        </span>
                      )}
                    </p>
                  </div>
                </div>

                {/* Controles Rápidos do Mini Player */}
                <div className="flex items-center gap-1 sm:gap-2">
                  <button
                    onClick={handlePrev}
                    className="p-2 text-zinc-300 hover:text-white hidden sm:inline-flex"
                  >
                    <SkipBack className="w-4 h-4 fill-current" />
                  </button>
                  <button
                    onClick={togglePlay}
                    className="w-10 h-10 rounded-xl bg-violet-600 hover:bg-violet-500 text-white flex items-center justify-center shadow-md"
                  >
                    {isPlaying ? <Pause className="w-5 h-5 fill-white" /> : <Play className="w-5 h-5 fill-white ml-0.5" />}
                  </button>
                  <button onClick={handleNext} className="p-2 text-zinc-300 hover:text-white">
                    <SkipForward className="w-4 h-4 fill-current" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Barra de Navegação Mobile-First */}
          <nav className="grid grid-cols-5 bg-zinc-950/95 border border-white/10 rounded-2xl p-1 backdrop-blur-xl">
            {[
              { id: 'explore', label: 'Explorar', icon: Compass },
              { id: 'local', label: 'Arquivos Locais', icon: HardDrive, badge: localTracks.length },
              { id: 'offline', label: 'Offline', icon: WifiOff, badge: offlineTracks.length },
              { id: 'extractor', label: 'Extrator', icon: PlusCircle },
              { id: 'handoff', label: 'Continuar/APK', icon: Smartphone }
            ].map((item) => {
              const Icon = item.icon;
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`relative flex flex-col items-center justify-center py-2 rounded-xl transition ${
                    active ? 'bg-violet-600/20 text-violet-300' : 'text-zinc-500 hover:text-zinc-300'
                  }`}
                >
                  <Icon className={`w-4 h-4 sm:w-5 sm:h-5 ${active ? 'text-violet-400' : ''}`} />
                  <span className="text-[10px] font-bold mt-1 truncate max-w-full px-1">{item.label}</span>
                  {item.badge > 0 && (
                    <span className="absolute top-1 right-3 px-1.5 py-0.2 rounded-full bg-fuchsia-600 text-white text-[9px] font-extrabold">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>
      </div>
    </div>
  );
}
