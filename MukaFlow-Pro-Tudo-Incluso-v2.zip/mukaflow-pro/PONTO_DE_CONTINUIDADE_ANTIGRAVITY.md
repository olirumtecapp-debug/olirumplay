# 🚀 PONTO DE CONTINUIDADE — MUKAFLOW PRO (ANTIGRAVITY + GITHUB APK)

Este documento contém o mapeamento arquitetural completo do **MukaFlow Pro v2.0**, instruções passo a passo de inicialização e o **Prompt Oficial de Continuidade** para colar no **Antigravity**.

---

## 📦 1. Estrutura do Pacote Compactado

```text
mukaflow-pro/
├── .github/
│   └── workflows/
│       └── build-apk.yml          # Pipeline automatizado que gera o .apk no GitHub Actions
├── android-config/
│   └── AndroidManifest.permissions.xml # Permissões de leitura de áudio local e segundo plano
├── public/
│   └── manifest.json              # Manifesto PWA instalável
├── src/
│   ├── App.jsx                    # Núcleo completo do MukaFlow Pro (UI + Audio Engine + ID3v2 + IndexedDB)
│   ├── main.jsx                   # Ponto de entrada React 18
│   └── index.css                  # Diretivas Tailwind CSS e estilização customizada
├── capacitor.config.json          # Configuração nativa do Capacitor 6 (com.mukaflow.player)
├── index.html                     # HTML raiz otimizado para WebView Android
├── package.json                   # Dependências (React, Lucide, Capacitor, Vite, Tailwind)
├── postcss.config.js              # Configuração PostCSS
├── tailwind.config.js             # Configuração Tailwind CSS
├── vite.config.js                 # Bundler Vite configurado para build mobile (`dist/`)
└── PONTO_DE_CONTINUIDADE_ANTIGRAVITY.md # Este guia de handoff
```

---

## ✅ 2. O Que Já Está 100% Implementado e Funcional (`src/App.jsx`)

1. **Motor de Áudio Híbrido + Web Audio API (`AudioContext`):**
   - Equalizador real de **5 Bandas** (`60Hz`, `230Hz`, `910Hz`, `3.6kHz`, `14kHz`) usando filtros `BiquadFilterNode` encadeados.
   - **Presets de Equalização:** Flat, Bass Boost, Electronic, Vocal & Podcast, Rock e Lo-Fi Night.
   - Controle de velocidade de reprodução (`0.75x`, `1.0x`, `1.25x`, `1.5x`).
   - **Sleep Timer** automático (15, 30, 45, 60 minutos) para desligar a música sozinho.
   - Visualizador de espectro de frequências renderizado em `<canvas>` a 60fps (`AnalyserNode`).
   - Integração com **Media Session API** (controles na tela de bloqueio e barra de notificação do Android).

2. **Leitor de Armazenamento Local (`Local Storage Scanner`):**
   - Importação de múltiplos arquivos (`.mp3`, `.m4a`, `.wav`, `.flac`, `.ogg`, `.aac`) ou escaneamento recursivo de pastas inteiras (`webkitdirectory`).
   - **Parser Binário Nativo de Tags ID3v2:** Lê diretamente os bytes do arquivo MP3 para extrair `TIT2` (Título), `TPE1` (Artista), `TALB` (Álbum) e `APIC` (extrai a imagem de capa embutida no MP3 sem precisar de bibliotecas externas).
   - Gerador automático de capas em SVG gradiente quando o MP3 não possui capa embutida.

3. **Cofre Offline Persistente (`IndexedDB - MukaFlowProDB`):**
   - Salva o `Blob` binário de áudio das músicas da nuvem ou do armazenamento local diretamente no banco de dados interno do app.
   - Permite ouvir qualquer música salva mesmo em **Modo Avião** e exportar o `.mp3` de volta para a pasta Downloads do celular.

4. **Playlists Customizadas, Favoritos e Fila de Reprodução:**
   - Criação de playlists personalizadas, marcação de favoritos e reordenação/remoção de faixas da fila atual.

---

## 🛠️ 3. Como Continuar no Antigravity (Passo a Passo)

1. Extraia este arquivo `.zip` em uma pasta no seu computador e abra a pasta no **Antigravity** (ou importe diretamente pelo workspace).
2. No terminal integrado do Antigravity, instale os pacotes e rode o servidor de desenvolvimento:
   ```bash
   npm install
   npm run dev
   ```
3. Copie o **Prompt de Continuidade** abaixo e envie para o agente do Antigravity na sua primeira mensagem.

---

## 🤖 4. PROMPT DE CONTINUIDADE PARA COLAR NO ANTIGRAVITY

Copie todo o bloco abaixo e cole no chat do Antigravity:

```markdown
Estou transferindo o projeto **MukaFlow Pro v2.0** (aplicativo híbrido de música estilo Muka Downloader / Spotify com armazenamento local e offline) que já está estruturado neste workspace.

### Arquitetura Atual no Workspace:
- `src/App.jsx`: Contém toda a interface mobile-first, motor de áudio HTML5 + Web Audio API (Equalizador de 5 bandas + Analyser Canvas), leitor binário nativo de tags ID3v2 (incluindo extração de capa APIC de arquivos MP3 locais), banco de dados offline IndexedDB (`MukaFlowProDB` v2 com stores `tracks` e `playlists`), busca integrada à API pública do iTunes, Sleep Timer, gerenciamento de fila e playlists.
- `capacitor.config.json` & `.github/workflows/build-apk.yml`: Já configurados para empacotar o app via Capacitor 6 e compilar o arquivo `.apk` automaticamente via GitHub Actions.

### Próximas Tarefas que quero desenvolver com você no Antigravity:
1. **Modularização Opcional:** Manter todas as funcionalidades de `src/App.jsx` intactas, podendo separar os módulos (`services/indexedDb.js`, `utils/id3Parser.js`, `components/EqualizerModal.jsx`) se necessário para escalabilidade.
2. **Scanner Nativo do Android (`@capacitor/filesystem`):** Adicionar um serviço complementar que utilize `@capacitor/filesystem` quando estiver rodando dentro do APK Android para varrer automaticamente as pastas `/storage/emulated/0/Music` e `/storage/emulated/0/Download` sem precisar abrir o seletor de arquivos manual.
3. **Microsserviço / API de Extração (Node.js / Vercel Serverless ou Render):** Criar uma rota de backend (`/api/extract?url=`) que receba links do YouTube/SoundCloud, extraia o stream de áudio real (`mp3`/`m4a`) e conecte na aba "Extrator" do `MukaFlow Pro`.
4. **Preparação para GitHub Actions:** Garantir que `npm run build` execute sem erros para que o workflow `.github/workflows/build-apk.yml` gere o APK perfeitamente no meu repositório GitHub.

Por favor, leia o arquivo `src/App.jsx` e `package.json` atuais para confirmar que compreendeu toda a estrutura antes de iniciarmos o próximo passo.
```
